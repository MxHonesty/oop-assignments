#include "Simulare.h"

Simulare::Simulare(QWidget* parent) : QMainWindow(parent) {
    ui.setupUi(this);
    setCentralWidget(lista);
}
